import pygame
import os
import random

current_path = os.path.dirname(__file__)
pygame.init()
win = pygame.display.set_mode((1280, 720))

cool_ship = pygame.image.load(os.path.join(current_path, 'cool_ship.png'))
ship = pygame.image.load(os.path.join(current_path, 'pixel_ship_yellow.png'))
enemy = pygame.image.load(os.path.join(current_path, 'pixel_ship_red_small.png'))
bg = pygame.image.load(os.path.join(current_path, 'stars.jpg'))
heal_pack = pygame.image.load(os.path.join(current_path, 'Health pack.png'))
clock = pygame.time.Clock()
lives = 10
shoot_count = 0
score = 0
lvl = 1
max_enemies = 10


class SpaceShip:

    def __init__(self, x, y, horizontal_vel, vertical_vel, health, height, width, timer):
        self.x = x
        self.y = y
        self.horizontal_vel = horizontal_vel
        self.vertical_vel = vertical_vel
        self.health = health
        self.height = height
        self.width = width
        self.timer = timer

    def move(self):
        if self.horizontal_vel > 0:  # if speed is in the right direction
            self.x += self.horizontal_vel
        if self.horizontal_vel < 0:  # if speed is in the left direction
            self.x += self.horizontal_vel
        if self.vertical_vel > 0:
            self.y += self.vertical_vel
        if self.vertical_vel < 0:
            self.y += self.vertical_vel

        win.blit(ship, (self.x, self.y))
        pygame.draw.rect(win, (255, 0, 0), (self.x + 25, self.y + 50 - 20, 50, 5))
        pygame.draw.rect(win, (0, 255, 0), (self.x + 25, self.y + 50 - 20, 50 + (self.health - 10) * 5, 5))

    def hit_box(self):
        pygame.draw.rect(win, (255, 0, 0), (self.x + 7, self.y + 10, self.height, self.width), 2)


class Projectile:
    def __init__(self, x, y, radius, color, facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 18 * facing

    def draw(self):  # wn in like win, the window the program is running on.
        global win
        pygame.draw.circle(win, self.color, (self.x, self.y), self.radius)


class Enemy:

    def __init__(self, x, y, level):
        self.x = x
        self.y = y
        self.vel = 3  # only one type of vel, simple enemies move straight and advanced ones use random side movements.
        self.width = 60
        self.height = 60
        self.level = level
        self.health = self.level

    def move(self):
        global win
        self.y += self.vel
        win.blit(enemy, (self.x, self.y))

    def fire(self):
        global enemy_shots
        enemy_shots.append(Projectile(self.x, self.y, 6, (120, 120, 255), 1))


class Boost:

    def __init__(self, x, y, heal):  # only one type of vel because boosts can only move down
        self.x = x
        self.y = y
        self.vel = random.randint(5, 9)
        self.heal = heal

    def move(self):
        global win
        self.y += self.vel
        win.blit(heal_pack, (self.x, self.y))


def limits():  # not in class because limits shouldn't affect other ships
    global player
    global bonuses
    if 0 > player.x:
        player.x = 0
    if player.x > 1280 - player.width:
        player.x = 1280 - player.width
    if player.y > 720 - player.height:
        player.y = 720 - player.height
    if player.y < 0:
        player.y = 0

    for bon in bonuses:
        if bon.y > 720:
            bonuses.pop(bonuses.index(bon))


def redrawGameWindow():
    global shoot_count
    win.blit(bg, (0, 0))
    font = pygame.font.SysFont('arial', size=30, bold=True)
    text = font.render('score: {}'.format(score), 1, (255, 0, 0))
    text2 = font.render('lives: {}'.format(lives), 1, (0, 255, 0))
    win.blit(text, (50, 30))
    win.blit(text2, (1150, 30))
    player.move()
    # player.hit_box()  # used for development
    limits()
    for x in bullets:
        x.draw()
    if shoot_count == 3:
        shoot_count = 0
    else:
        shoot_count += 1
    for hostile in enemies:
        hostile.move()
    for m in bonuses:
        m.move()
    for en in enemy_shots:
        en.draw()


enemy_count = 130
max_bon_level = 3
total_iterations = 0
bonus_rarity = 1200
bonuses = []
enemies = []
enemy_shots = []
bullets = []  # keep track of bullets on the screen
player = SpaceShip(640, 360, 0, 0, 10, 100, 100, 0)  # player's character

run = True
while run:
    clock.tick(60)  # 60 fps
    pygame.display.update()
    # resets the speed here instead of in the if statements. simply easier
    player.vertical_vel = 0
    player.horizontal_vel = 0
    enemy_gen = random.randint(1, enemy_count)
    enemy_lvl = random.randint(1, lvl)
    bonus_count = random.randint(1, bonus_rarity)
    total_iterations += 1

    if bonus_count == 6 and len(bonuses) < 3:  # chooses when to spawn health packs
        bonuses.append(Boost(random.randint(80, 1200), -80, random.randint(1, max_bon_level)))

    if enemy_gen == 4 and len(enemies) < max_enemies:  # chooses when to spawn enemy ships
        enemies.append(Enemy(random.randint(80, 1200), -80, random.randint(1, 2)))

    for danger in enemy_shots:
        if player.x < danger.x < player.x + player.width:
            if player.y < danger.y < player.y + player.height:  # if the enemies hit the player
                player.health -= 1
                enemy_shots.pop(enemy_shots.index(danger))

        danger.y += danger.vel // 3

        if danger.y > 720:  # if the enemy bullets are out of the screen
            try:  # resulted some sort of error so we just ignore it
                enemy_shots.pop(enemy_shots.index(danger))
            except ValueError:
                print("couldn't delete some object for some reason, this is only here not to throw an error")

    for bonus in bonuses:  # if player catches the bonus
        if player.x - player.width < bonus.x < player.x + player.width:
            if player.y < bonus.y < bonus.y + player.height:
                player.health += bonus.heal
                bonuses.pop(bonuses.index(bonus))
                print("picked a health pack. + {} lives".format(bonus.heal))

    if lives < 0:
        run = False
        print("You ran out of lives!")

    if player.health < 0:
        run = False
        print("Your ship exploded!")

    for i in enemies:  # removes enemies that passed the bottom of the screen and decreases the life count
        if i.y > 720:
            enemies.pop(enemies.index(i))
            lives -= 1
            print('lost a life. lives left:', lives)

        for bullet in bullets:  # i stands for enemy because I am an idiot
            if i.x < bullet.x + 3 < i.x + i.width:
                if i.y < bullet.y + 3 < i.y + i.width:
                    bullets.pop(bullets.index(bullet))
                    if i.health <= 1:  # when there's only 1 life left the enemy dies
                        enemies.pop(enemies.index(i))
                        score += 1
                    else:
                        i.health -= 1  # decreases one life for every hit

        if player.y < i.y < player.y + player.width:  # when enemy ships collide with player
            if player.x < i.x < player.x + player.height:
                enemies.pop(enemies.index(i))
                player.health -= 1

        to_shoot = random.randint(1, 300)  # chooses how often the enemies shoot

        if to_shoot == 23:
            i.fire()

    for event in pygame.event.get():  # allows program to be closed when hitting X button
        if event.type == pygame.QUIT:
            run = False
            break

    keys = pygame.key.get_pressed()  # list of all clicked keys

    # right and left movements
    if keys[pygame.K_d] or keys[pygame.K_RIGHT]:  # move right
        player.horizontal_vel = 13
    elif keys[pygame.K_a] or keys[pygame.K_LEFT]:  # move left
        player.horizontal_vel = -13
    else:
        player.vertical_vel = 0

    # up and down movements
    if keys[pygame.K_w] or keys[pygame.K_UP]:
        player.vertical_vel = -9
    elif keys[pygame.K_s] or keys[pygame.K_DOWN]:
        player.vertical_vel = 9
    else:
        player.vertical_vel = 0

    if keys[pygame.K_LCTRL]:
        player.vertical_vel /= 2
        player.horizontal_vel /= 1.5

    if keys[pygame.K_SPACE] and shoot_count == 0 and len(bullets) < 15:  # for shooting
        bullets.append(Projectile(round(player.x + player.width // 2), round(player.y + player.height // 2), 6,
                                  (255, 0, 0), -1))

    for bullet in bullets:  # moving the bullets in the desired direction
        if 0 < bullet.y < 720:
            bullet.y += bullet.vel
        else:
            bullets.pop(bullets.index(bullet))

    if total_iterations % 100 == 1:  # increases the likelihood for bonus every few seconds
        bonus_rarity -= 5

    if total_iterations % 1500 == 1:  # increases the maximum health that can be received from health packs
        max_bon_level += 1
        print("Total iterations:", total_iterations)

    if score % 3 == 0 and enemy_count > 40:  # decreases the rarity of enemy spawn (makes more of them spawn)
        enemy_count -= 3

    redrawGameWindow()  # simply redraws everything depending on the changed parameters

pygame.quit()
